/** 
*	Versión del algoritmo sigue líneas para 3 estados usando 1 sensor de Cliff
*/

#include "ControlRobot.h"

using namespace std;


/*
 
int main(int argc, char * argv[])
{
	
	ControlRobot robot;
	
	robot.inicializacion();
	
	while(!robot.condicionSalida()){
		robot.leerSensores();
		robot.logicaEstados();
		robot.moverActuadores();
		robot.imprimirInfo();

	}

	robot.finalizacion();
	return 0;
}

 * */